class Solution {
    public boolean isNumber(String s) {
        if (s == null) {
            return false;
        }

        // The problem permits leading and trailing spaces.
        s = s.trim();
        if (s.isEmpty()) {
            return false;
        }

        // A valid number may have an optional sign, decimal part, and exponent.
        // If an exponent exists, it must contain at least one digit.
        String pattern = "[+-]?((\\d+(\\.\\d*)?)|(\\.\\d+))([eE][+-]?\\d+)?";
        return s.matches(pattern);
    }
}

// Time: O(n), where n is the length of the input string.
// Space: O(n) for the regular-expression matching process.
