class Solution {
    public int removeElement(int[] nums, int val) {
        int write = 0;

        // Copy each value different from val to the next available position.
        for (int read = 0; read < nums.length; read++) {
            if (nums[read] != val) {
                nums[write] = nums[read];
                write++;
            }
        }

        // The first 'write' positions contain the kept elements.
        return write;
    }
}

// Time: O(n).
// Space: O(1).
