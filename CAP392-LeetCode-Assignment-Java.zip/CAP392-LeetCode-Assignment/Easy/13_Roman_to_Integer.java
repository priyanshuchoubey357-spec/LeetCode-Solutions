import java.util.*;

class Solution {
    public int romanToInt(String s) {
        Map<Character, Integer> values = new HashMap<>();
        values.put('I', 1);
        values.put('V', 5);
        values.put('X', 10);
        values.put('L', 50);
        values.put('C', 100);
        values.put('D', 500);
        values.put('M', 1000);

        int total = 0;

        for (int i = 0; i < s.length(); i++) {
            int current = values.get(s.charAt(i));

            // A smaller value before a larger value is subtracted.
            if (i + 1 < s.length() && current < values.get(s.charAt(i + 1))) {
                total -= current;
            } else {
                total += current;
            }
        }

        return total;
    }
}

// Time: O(n), where n is the length of the Roman numeral.
// Space: O(1), because the map contains a fixed number of symbols.
