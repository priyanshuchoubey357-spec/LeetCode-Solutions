class Solution {
    public int reverse(int x) {
        long reversed = 0;
        int number = x;

        while (number != 0) {
            int digit = number % 10;
            reversed = reversed * 10 + digit;

            // The answer must fit in a signed 32-bit integer.
            if (reversed > Integer.MAX_VALUE || reversed < Integer.MIN_VALUE) {
                return 0;
            }

            number /= 10;
        }

        return (int) reversed;
    }
}

// Time: O(log |x|) — one iteration per digit.
// Space: O(1).
