class Solution {
    public int[] plusOne(int[] digits) {
        for (int i = digits.length - 1; i >= 0; i--) {
            if (digits[i] < 9) {
                digits[i]++;
                return digits;
            }

            // A 9 becomes 0 and the carry moves to the left.
            digits[i] = 0;
        }

        // All digits were 9, so the result has one extra digit.
        int[] result = new int[digits.length + 1];
        result[0] = 1;
        return result;
    }
}

// Time: O(n) in the worst case.
// Space: O(1) extra space normally; O(n) for the returned array when all digits are 9.
