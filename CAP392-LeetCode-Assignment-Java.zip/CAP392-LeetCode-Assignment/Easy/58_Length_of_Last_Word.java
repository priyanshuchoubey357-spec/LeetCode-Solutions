class Solution {
    public int lengthOfLastWord(String s) {
        int index = s.length() - 1;

        // Skip trailing spaces.
        while (index >= 0 && s.charAt(index) == ' ') {
            index--;
        }

        int length = 0;

        // Count characters in the last word.
        while (index >= 0 && s.charAt(index) != ' ') {
            length++;
            index--;
        }

        return length;
    }
}

// Time: O(n) in the worst case.
// Space: O(1).
