class Solution {
    public boolean isPalindrome(int x) {
        // Negative numbers and numbers ending in zero (except 0) cannot be palindromes.
        if (x < 0 || (x % 10 == 0 && x != 0)) {
            return false;
        }

        int reversedHalf = 0;

        // Reverse only half the digits to avoid integer overflow.
        while (x > reversedHalf) {
            reversedHalf = reversedHalf * 10 + x % 10;
            x /= 10;
        }

        // For an even number of digits, both halves are equal.
        // For an odd number, ignore the middle digit of reversedHalf.
        return x == reversedHalf || x == reversedHalf / 10;
    }
}

// Time: O(log10 n).
// Space: O(1).
