# CAP392 LeetCode Assignment — Java Solutions

This repository contains Java solutions for the 16 problems listed in the
provided `D1P2516_CAP392_Leet_Code_Problems.xlsx` assignment.

## Problems

### Easy
1. [7 — Reverse Integer](Easy/7_Reverse_Integer.java)
2. [9 — Palindrome Number](Easy/9_Palindrome_Number.java)
3. [13 — Roman to Integer](Easy/13_Roman_to_Integer.java)
4. [14 — Longest Common Prefix](Easy/14_Longest_Common_Prefix.java)
5. [27 — Remove Element](Easy/27_Remove_Element.java)
6. [35 — Search Insert Position](Easy/35_Search_Insert_Position.java)
7. [58 — Length of Last Word](Easy/58_Length_of_Last_Word.java)
8. [66 — Plus One](Easy/66_Plus_One.java)
9. [125 — Valid Palindrome](Easy/125_Valid_Palindrome.java)

### Medium
10. [56 — Merge Intervals](Medium/56_Merge_Intervals.java)
11. [189 — Rotate Array](Medium/189_Rotate_Array.java)
12. [31 — Next Permutation](Medium/31_Next_Permutation.java)
13. [54 — Spiral Matrix](Medium/54_Spiral_Matrix.java)
14. [73 — Set Matrix Zeroes](Medium/73_Set_Matrix_Zeroes.java)

### Hard
15. [65 — Valid Number](Hard/65_Valid_Number.java)
16. [41 — First Missing Positive](Hard/41_First_Missing_Positive.java)

## How to use these files on LeetCode

- Each file uses the LeetCode method signature and class name `Solution`.
- Open the matching problem on LeetCode, choose **Java**, and paste the code
  from the corresponding file into the editor.
- These files are kept in separate folders because each file defines a class
  named `Solution`; compile/run one solution at a time.
- Review and understand each solution before submitting it as your own work.

## Complexity

Each solution file includes its time and auxiliary space complexity in comments.
